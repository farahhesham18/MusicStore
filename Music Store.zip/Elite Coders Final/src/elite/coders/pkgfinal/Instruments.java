/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package elite.coders.pkgfinal;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author farah hesham
 */
public class Instruments extends Inventory{
   
    
    protected String Name;
    protected double Price;
    protected int points , amount;

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public double getPrice() {
        return Price;
    }

    public void setPrice(double Price) {
        this.Price = Price;
    }

    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points = points;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }
    
    @Override
    public String toString()
    {
        return("Name:"+Name+"/nPrice"+Price+"/nAmount"+amount+"/nPoints"+points);
    }
    
    
    public double insurance()
    {
        return(Price+1000);
        
    }
    
    public void PointCalculation()
    {  if (points>=1 && points<=5)
    {
      Price=Price; // no discount
    
    }
    else  if  (points>5 && points<=10)
    {
      Price=Price-(Price/10); //10percent
    
    }
    else  if  (points>10 && points<=20)
    {
      Price=Price-(Price/5); //20 percent
    
    }
    else  if  (points>20&& points<=30)
    {
      Price=Price-(Price/2.5); //30 percent
    
    }
    else  if  (points>30 && points<=50)
    {
      Price=Price-(Price/2); //50 percent
    
    }
    else if (points>50)
    {
    Price=Price-(Price/1.6); //75 percent
    
    }
    
    
    }
    
    
     //setalignmentt        
    //setvgap sethgap
    
}

