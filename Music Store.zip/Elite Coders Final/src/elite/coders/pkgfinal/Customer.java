/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package elite.coders.pkgfinal;

/**
 *
 * @author farah hesham
 */
public class Customer {
    
       private String name,E_Mail,PhoneNo,adress,username,password;

    public Customer(String name, String E_Mail, String PhoneNo, String adress, String username, String password) {
        this.name = name;
        this.E_Mail = E_Mail;
        this.PhoneNo = PhoneNo;
        this.adress = adress;
        this.username = username;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getE_Mail() {
        return E_Mail;
    }

    public void setE_Mail(String E_Mail) {
        this.E_Mail = E_Mail;
    }

    public String getPhoneNo() {
        return PhoneNo;
    }

    public void setPhoneNo(String PhoneNo) {
        this.PhoneNo = PhoneNo;
    }

    public String getAdress() {
        return adress;
    }

    public void setAdress(String adress) {
        this.adress = adress;
    }

 
    
    
   @Override
    public String toString()
    {
        return("Name:"+name+"Phone Number:"+PhoneNo+"Email :"+E_Mail+"Adress:"+adress);
    }
    
    
    
}
