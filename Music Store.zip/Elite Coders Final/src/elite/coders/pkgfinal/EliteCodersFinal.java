/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package elite.coders.pkgfinal;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import elite.coders.pkgfinal.Instruments;
import java.awt.Color;
import static javafx.application.Application.launch;
import javafx.scene.control.ListView;
import javafx.scene.text.FontPosture;

/**
 *
 * @author farah hesham
 */
public class EliteCodersFinal extends Application {
    
  Scene Welcome_Menu, customer_in,Subscriber_in,Login,Sign_Up;
    GridPane grid1, grid2,grid3,grid4,grid5;

 @Override
 public void start(Stage primaryStage) {
  

         //first Scene Welcome Menu
         Text f = new Text("Welcome To Our MusicStore");
         f.setFont(Font.font(50));
         grid1 = new GridPane();
         Button Customer = new Button("Customer");
         Button Subscriber = new Button("Subscriber");
         Customer.setStyle("-fx-background-color: white; -fx-text-fill: Black;"); 
         Subscriber.setStyle("-fx-background-color: white; -fx-text-fill: Black;"); 
         Customer.setFont(Font.font(40));
         Subscriber.setFont(Font.font(40));
         grid1.setVgap(5);
         grid1.setHgap(5);
         grid1.setAlignment(Pos.CENTER);
         grid1.add(Customer, 1, 3);
         grid1.add(Subscriber, 0, 3);
        // grid1.add(f,0,0);
         Welcome_Menu = new Scene(grid1, 1000, 1000);
         
         
         
         
         Subscriber.setOnAction(new EventHandler<ActionEvent>() 
         {
          @Override
          public void handle(ActionEvent t) {
                   //going to subscriber scene
                   primaryStage.setScene(Subscriber_in);
                   primaryStage.show();
     
                     }
                 }
         );
         
         Customer.setOnAction(new EventHandler<ActionEvent>() 
         {
          @Override
          public void handle(ActionEvent t) {
                   //going to subscriber scene
                   primaryStage.setScene(customer_in);
                   primaryStage.show();
     
                     }
                 }
         );
         //Scene customer
         
         grid5=new GridPane();
         
         
         VBox Layout = new VBox();
         ListView<Instruments> instrumentView=new ListView<>();
         instrumentView.getItems().addAll();
         //instrumentView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
         Layout.getChildren().addAll(instrumentView);
         
         BorderPane BP= new BorderPane();
        // BP.setCenter(grid5);
         BP.setLeft(Layout);
         //Making list choosing from
         customer_in = new Scene(grid5, 600, 600);
         
         
        
         //The Subscriber Scene
         grid2=new GridPane();
         Subscriber_in = new Scene(grid2, 400, 400);
         //Buttons
         Button SignIn = new Button("SignIn  ");
         Button SignUp = new Button("SignUp  ");
         Button Back1 = new Button("Back  ");
         SignIn.setStyle("-fx-background-color: ROSYBROWN; -fx-text-fill: white;"); 
         SignUp.setStyle("-fx-background-color: ROSYBROWN; -fx-text-fill: white;"); 
         Back1.setStyle("-fx-background-color: 	ROSYBROWN; -fx-text-fill: white;"); 
         SignIn.setFont(Font.font(30));
         SignUp.setFont(Font.font(30));
         Back1.setFont(Font.font(30));
         //add grid
         grid2.add(SignIn, 2, 0);
         grid2.add(SignUp, 2,1);
         grid2.add(Back1, 2,2);
         grid2.setVgap(20);
         grid2.setHgap(20);
         grid2.setStyle("-fx-background-color: SEASHELL;"); 
         SignIn.setOnAction(new EventHandler<ActionEvent>() {

                     @Override
                     public void handle(ActionEvent t) {
                     
                     primaryStage.setScene(Login);
                     primaryStage.show();
     
                     }
                 }
         );
         SignUp.setOnAction(new EventHandler<ActionEvent>() {

                @Override
                public void handle(ActionEvent t) {
                
                primaryStage.setScene(Sign_Up);
                primaryStage.show();

                }
            }
    );
         Back1.setOnAction(new EventHandler<ActionEvent>() {

                     @Override
                     public void handle(ActionEvent t) {
                     
                     primaryStage.setScene(Welcome_Menu);
                     primaryStage.show();
                     }
                 }
         );
        
         //SignUp Scene
           grid4=new GridPane();
          Sign_Up = new Scene(grid4, 500, 500);
          
          Text lconfirm = new Text();
          Text UserName_FullName = new Text ("FullName:");
          TextField Fulltxt = new TextField();
          Text Email = new Text ("Email:");
          TextField Emailtxt = new TextField();
          Text PhNumber = new Text ("Phone Number:");
          TextField Phtxt = new TextField();
          Text Adress = new Text ("Adress:");
          TextField Adresstxt = new TextField();  
          Text UserName_FirstTime = new Text ("UserName:");
          TextField UNFtxt = new TextField();
          Text Password = new Text ("Password:");
          PasswordField Passwordtxt = new PasswordField();
          //styling the texts 
          Password .setStyle("-fx-font: normal bold 20px 'serif' "); 
          Email.setStyle("-fx-font: normal bold 20px 'serif' ");  
          PhNumber.setStyle("-fx-font: normal bold 20px 'serif' "); 
          Adress.setStyle("-fx-font: normal bold 20px 'serif' ");
          UserName_FullName  .setStyle("-fx-font: normal bold 20px 'serif' "); 
         UserName_FirstTime.setStyle("-fx-font: normal bold 20px 'serif' ");  
          //Buttons 
          Button Confirm = new Button("Confirm");
          Button Back2 = new Button("Back");
          //Button Styling
          Confirm.setStyle("-fx-background-color: LIGHTBLUE; -fx-text-fill: white;"); 
          Back2.setStyle("-fx-background-color: LIGHTBLUE; -fx-text-fill: white;"); 
          //Grid 
          grid4.setAlignment(Pos.CENTER);
          grid4.add(UserName_FullName, 0, 0);
          grid4.add(Fulltxt, 1, 0);
          grid4.add(Email, 0, 1);
          grid4.add(Emailtxt, 1, 1);
          grid4.add(PhNumber, 0, 2);
          grid4.add(Phtxt, 1, 2);
          grid4.add(Adress, 0, 3);
          grid4.add(Adresstxt, 1, 3);
          grid4.add(UserName_FirstTime, 0, 4);
          grid4.add(UNFtxt, 1, 4);
          grid4.add(Password, 0, 5);
          grid4.add(Passwordtxt, 1, 5);
          grid4.add(Confirm, 2, 6);
          grid4.add(Back2, 0, 6);
          grid4.add(lconfirm, 3, 6);
          grid4.setHgap(10);
          grid4.setVgap(10);
          grid4.setStyle("-fx-background-color: FLORALWHITE;"); 
          
          
          //Back Button
          Back2.setOnAction(new EventHandler<ActionEvent>() {

                 @Override
                 public void handle(ActionEvent t) {
                 
                 primaryStage.setScene(Subscriber_in);
                 primaryStage.show();
                 }
             }
     );
          //confirm Button
          
          Confirm.setOnAction(e -> {
          String namet = Fulltxt.getText();
          String Emaailt = Emailtxt.getText();
          String Phonet = Phtxt.getText();
          String Adresst = Adresstxt.getText();
          String Usernamet = UNFtxt.getText();
          String passt = Passwordtxt.getText();
            //Create Customer Object
          Customer c = new Customer(namet,Adresst,Usernamet,Emaailt,Phonet,passt);
            //add object to Customer List
           Person.addCustomer(c);
           lconfirm.setText("Added "+ Usernamet);
                 }
             
     );
         //The LogIn Scene
          grid3=new GridPane();
          Login = new Scene(grid3, 600, 600);
         // Texts And Text Fields
         Text UserName = new Text ("UserName:");
         TextField usrtxt = new TextField();
         final Label Done = new Label();
         Text PassWord = new Text ("PassWord:");
         PasswordField passtxt = new PasswordField(); 
         PassWord.setFont(Font.font("RED", FontPosture.ITALIC, 20));
         UserName.setFont(Font.font("RED", FontPosture.ITALIC, 20));
          //Buttons
         Button Login = new Button("Login");
         Button Back = new Button("Back");
         Back.setStyle("-fx-background-color: SKYBLUE; -fx-text-fill: white;"); 
         Login.setStyle("-fx-background-color: SKYBLUE; -fx-text-fill: white;"); 
         //The grid
         grid3.add(UserName,0,0);
         grid3.add(usrtxt,1,0);
         grid3.add(PassWord,0,1);
         grid3.add(passtxt,1,1);
         grid3.add(Login,1,2);
         grid3.add(Back,2,2);
         grid3.setVgap(10);
         grid3.setHgap(10);
         grid3.add(Done, 0, 3);
         grid3.setAlignment(Pos.CENTER);
         grid3.setStyle("-fx-background-color: FLORALWHITE;"); 
         Login.setOnAction(new EventHandler<ActionEvent>() {
           @Override
                     public void handle(ActionEvent t) {
                     
                        String userName = usrtxt.getText();
                        String password = passtxt.getText();
                      if (userName.trim().equals("Farah") && password.trim().equals("1234")) {
                           Done.setText("Welcome Manager");
                           
                        }
                      else {
                            Done.setText("Welcome To Our App");
                           
                          }
     
                     }
                 });
   
         Back.setOnAction(new EventHandler<ActionEvent>() {

                     @Override
                     public void handle(ActionEvent t) {
                     
                     primaryStage.setScene(Subscriber_in);
                     primaryStage.show();
                     }
                 }
         );

         primaryStage.setTitle("Music Store App");
         primaryStage.setScene(Welcome_Menu);
         grid1.getStylesheets().add(getClass().getResource("css.css").toExternalForm());
         primaryStage.show();
     }

     public static void main(String[] args) {
         launch(args);
     }

}
//Scene ManagerOptions,manageScene;
//    //Stage window=new Stage();
//    GridPane grid_ManagerAuthorities=new GridPane();
//    Button Show=new Button("Show");
//    Button Manage=new Button("Manage");
//    grid_ManagerAuthorities.add(Show,0, 0);
//    grid_ManagerAuthorities.add(Manage,1, 0);
//    grid_ManagerAuthorities.setHgap(30);
//    grid_ManagerAuthorities.setAlignment(Pos.CENTER);
//      ManagerOptions=new Scene(grid_ManagerAuthorities, 400, 200);
//     
//        //show
//        
//        
//        //Manage
//        FadeTransition added,removed;
//        Text Instruments=new Text("Instruments");
//        Text Added=new Text();
//        Text Removed=new Text();
//        Text Name=new Text("Name");
//        Text Price=new Text("Price");
//        Text Points=new Text("Points");
//        Text Amount=new Text("Amount");
//        TextField name=new TextField();
//        TextField price=new TextField();
//        TextField points=new TextField();
//        TextField amount=new TextField();
//        Button Add_Item=new Button("Add");
//        Button Remove_Item=new Button("Remove");
//        Button Clear=new Button("Clear");
//        Button Back_toManage=new Button("Back");
//        added=new FadeTransition(Duration.seconds(9), Added);
//        added.setFromValue(1);
//        added.setToValue(0);
//        added.play();
//        removed=new FadeTransition(Duration.seconds(9), Removed);
//        removed.setFromValue(1);
//        removed.setToValue(0);
//        removed.play();
//        //Grid
//        GridPane grid_manageMenu=new GridPane();
//        grid_manageMenu.setHgap(30);
//        grid_manageMenu.setVgap(20);
//        grid_manageMenu.add(Name, 0, 0);
//        grid_manageMenu.add(Price, 0, 1);
//        grid_manageMenu.add(Points, 0, 2);
//        grid_manageMenu.add(Amount, 0, 3);
//        grid_manageMenu.add(name, 1, 0);
//        grid_manageMenu.add(price, 1, 1);
//        grid_manageMenu.add(points, 1, 2);
//        grid_manageMenu.add(amount, 1, 3);
//        grid_manageMenu.add(Back_toManage, 5, 4);
//        grid_manageMenu.add(Clear, 3, 4);
//        grid_manageMenu.add(Added, 1, 4);
//        grid_manageMenu.add(Removed, 1, 4);
//        grid_manageMenu.add(Add_Item, 2, 4);
//        grid_manageMenu.add(Remove_Item, 4, 4);
//       
//        
//        //grid_manageMenu.setAlignment(Pos.CENTER);
//        
//       //vBox
//        ListView<Instruments>instrumentView=new ListView<>();
//        for (Instruments ins : Inventory.getGuitarAndBass()) {
//            instrumentView.getItems().add(ins);
//        }
//        VBox vbox_instrumentsList=new VBox();
//        vbox_instrumentsList.getChildren().addAll(Instruments,instrumentView);
//        //vbox_instrumentsList.setAlignment(Pos.BASELINE_LEFT);
//        
//        //Border
//        BorderPane All_Panes=new BorderPane();
//        //All_Panes.getChildren().addAll(vbox_instrumentsList,grid_manageMenu);
//        All_Panes.setRight(grid_manageMenu);
//        All_Panes.setLeft(vbox_instrumentsList);
//        
//        
//       manageScene=new Scene(All_Panes,1024,768);
//       
//        //Buttons
//        Add_Item.setOnAction((ActionEvent event) -> {
//            String Name_cpy = name.getText();
//                  Double Price_cpy = Double.parseDouble(price.getText());
//                  Integer Amount_cpy = Integer.parseInt(amount.getText());
//                  Integer Points_cpy = Integer.parseInt(points.getText());
//                 
//            
//            
//            //Create Instrument Object
//            
//            Instruments o1 = new Instruments(Name_cpy,Price_cpy,Amount_cpy,Points_cpy);
//           
//            //add object to Invetory List
//            
//            Inventory.addItem(o1);
//            Added.setText("Added");
//        
//                
//           
//            
//    });