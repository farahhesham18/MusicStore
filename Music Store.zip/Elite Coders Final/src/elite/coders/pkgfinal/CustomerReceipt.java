/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package elite.coders.pkgfinal;

import java.util.ArrayList;

/**
 *
 * @author farah hesham
 */
public class CustomerReceipt {
    
    
    
       private int id ;
    ArrayList <Instruments> receipt = new ArrayList <>();

    public int getId() {
        return id;
    }
 
    
   public void  additem(Instruments g)
   {
       receipt.add(g); 
       
   }
    public void  removeitem(Instruments g)
   {
       receipt.add(g); 
   }
   
    public void  cancleitem(Instruments g)
   {
       receipt.clear(); 
   }
   
    public double Cost ()
    {
        
    double cost =0;
    for(int i=0 ; i<receipt.size();i++)
    { 
       cost= cost+ receipt.get(i).getPrice();
    }
    
    return cost;
    }
    
     public double CostInsorance ()
    {
        
    double cost =0;
    for(int i=0 ; i<receipt.size();i++)
    { 
       cost= cost+ receipt.get(i).getPrice();
    }
    cost=cost+1000;
    
    return cost;
    }
}
