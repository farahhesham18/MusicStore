/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package elite.coders.pkgfinal;

import java.util.Date;

/**
 *
 * @author farah hesham
 */
public class Transactions extends Inventory{
     private Date date;
     private String type;
     private int amount;
     private double Price;
     
     
     
    public Transactions(Date date, String type, int amount, double Price) {
        this.date = date;
        this.type = type;
        this.amount = amount;
        this.Price = Price;
    }
     

    public Date getDate() {
        return date;
    }

    public String getType() {
        return type;
    }

    public int getAmount() {
        return amount;
    }

    public double getPrice() {
        return Price;
    }
    @Override
     public String toString()
     {
         return date+"/n"+type+"/n"+amount+"/n"+Price+"/n";
     }
     
}
