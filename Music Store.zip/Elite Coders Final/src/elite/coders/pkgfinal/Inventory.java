/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package elite.coders.pkgfinal;


import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author farah hesham
 */
public class Inventory {
    ArrayList<Instruments>GuitarAndBass= new ArrayList<>();
    ArrayList<Instruments>PianosAndKeyboards= new ArrayList<>();
    ArrayList<Instruments>DrumsAndPercussions= new ArrayList<>();
    ArrayList<Instruments>Orchestra= new ArrayList<>();
    ArrayList<Instruments>StudioEquipments= new ArrayList<>();
    ArrayList<Instruments>Parts= new ArrayList<>();
    ArrayList<Instruments>All= new ArrayList<>();
    
    public void GuitarAndBassAdd(String name, double price , int amount , int points)
    {
        Instruments g=new Instruments();
        g.setName(name);
        g.setAmount(amount);
        g.setPoints(points);
        g.setPrice(price);
        GuitarAndBass.add(g);
        All.add(g);
    }
     public void PianosAndKeyboardsAdd(String name, double price , int amount , int points)
    {
        Instruments g=new Instruments();
        g.setName(name);
        g.setAmount(amount);
        g.setPoints(points);
        g.setPrice(price);
        PianosAndKeyboards.add(g);
        All.add(g);
    }
    public void OrchestraAdd(String name, double price , int amount , int points)
    {
        Instruments g=new Instruments();
        g.setName(name);
        g.setAmount(amount);
        g.setPoints(points);
        g.setPrice(price);
        Orchestra.add(g);
        All.add(g);
    }
    public void StudioEquipmentsAdd(String name, double price , int amount , int points)
    {
        Instruments g=new Instruments();
        g.setName(name);
        g.setAmount(amount);
        g.setPoints(points);
        g.setPrice(price);
        StudioEquipments.add(g);
        All.add(g);
    }
    public void DrumsAndPercussionsAdd(String name, double price , int amount , int points)
    {
        Instruments g=new Instruments();
        g.setName(name);
        g.setAmount(amount);
        g.setPoints(points);
        g.setPrice(price);
        DrumsAndPercussions.add(g);
        All.add(g);
    }
    public void PartsAdd(String name, double price , int amount , int points)
    {
        Instruments g=new Instruments();
        g.setName(name);
        g.setAmount(amount);
        g.setPoints(points);
        g.setPrice(price);
        Parts.add(g);
        All.add(g);
    }
    // remove
      public void GuitarAndBassremove(Instruments g)
    {
     
        GuitarAndBass.remove(g);
        All.remove(g);
    }
     public void PianosAndKeyboardsremove(Instruments g)
    {
      
        PianosAndKeyboards.remove(g);
        All.remove(g);
    }
    public void Orchestraremove(Instruments g)
    {
       
        Orchestra.remove(g);
        All.remove(g);
    }
    public void StudioEquipmentsremove(Instruments g)
    {
       
        StudioEquipments.remove(g);
        All.remove(g);
    }
    public void DrumsAndPercussionsremove(Instruments g)
    {
       
        DrumsAndPercussions.remove(g);
        All.remove(g);
    }
    public void Partsremove(Instruments g)
    {
       
        Parts.remove(g);
        All.remove(g);
    }

    
    
    
    
    
    
    
    
}

