/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package elite.coders.pkgfinal;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author farah hesham
 */

import java.util.ArrayList;

public class Person {

    static ArrayList <Customer> CusList = new ArrayList <>();

    static public ArrayList<Customer> CusList() {
        return CusList;
    }

    static public void addCustomer(Customer C) {
        CusList.add(C);
    }

    static public void removeCustomer(Customer C) {
        CusList.remove(C);
    }
}

 

